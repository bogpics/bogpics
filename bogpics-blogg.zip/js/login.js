
function checkLogin() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if (user === "demo" && pass === "demo123") {
    document.getElementById('loginResult').innerText = "Inloggad! 💖";
  } else {
    document.getElementById('loginResult').innerText = "Fel användarnamn eller lösenord.";
  }
  return false; // Prevent form submission
}
